#include "Map.h"
#include <iostream>
using namespace std;

Map::Map()
:head(nullptr), tail(nullptr), m_curSize(0)
{
   
}

Map::~Map()
{
    Node* current = head;
    while (current != nullptr)
    {
        Node* next = current->next;
        delete current;
        current = next;
    }
}

// Copy constructor
Map::Map(const Map& other)
:head(nullptr), tail(nullptr), m_curSize(0)
{
    Node* otherCurrent = other.head;
    while (otherCurrent != nullptr)
    {
        insert(otherCurrent->key, otherCurrent->value);
        otherCurrent = otherCurrent->next;
    }
}

// Assignment operator
Map& Map::operator=(const Map& rhs)
{
    if (this != &rhs)
    {   
        // Erase all elements
        while (!empty())
        {
            erase(head->key);
        }
        // Copy all nodes from other map
        Node* rhsCurrent = rhs.head;
        while (rhsCurrent != nullptr)
        {
            insert(rhsCurrent->key, rhsCurrent->value);
            rhsCurrent = rhsCurrent->next;
        }
    }
    return *this;
}

bool Map::empty() const
{
    return m_curSize == 0;
}

int Map::size() const
{
    return m_curSize;
}

bool Map::insert(const KeyType& key, const ValueType& value)
{   
    // Check if key exists in list
    Node* current = head;
    while (current != nullptr)
    {
        if (current->key == key)
        {
            return false;
        }
        current = current->next;
    }

    // Create new node
    Node* newNode = new Node{key, value, nullptr, nullptr};

    // If list is empty, point head and tail at newNode,
    // set next and prev pointers to nullptr
    if (head == nullptr)
    {
        head = tail = newNode;
        newNode->next = nullptr;
        newNode->prev = nullptr;
    }
    // If list not empty, point *prev to the old last node (where tail points).
    // Point the old last node's *next to newNode. 
    // Point tail to newNode
    // Set newNode's next to nullptr
    else
    {
        newNode->prev = tail;
        tail->next = newNode;
        tail = newNode;
        newNode->next = nullptr;
    }

    // Indicate added node and return true
    m_curSize++;
    return true;
}

bool Map::update(const KeyType& key, const ValueType& value)
{
    Node* current = head;
    // Search through list
    while (current != nullptr)
    {
        // If key matches, update the value
        if (current->key == key)
        {
            current->value = value;
            return true;
        }
        current = current->next;
    }
    // No key found
    return false;
}


bool Map::insertOrUpdate(const KeyType& key, const ValueType& value)
{
    if (update(key, value))
    {
        return true;
    }
    return insert(key, value);
}

bool Map::erase(const KeyType& key)
{
    Node* current = head;
    while (current != nullptr)
    {   

        if (current->key == key)
        {   
            // If not first item
            if (current->prev != nullptr) {
                // Point previous node *next to current's next node
                current->prev->next = current->next;
            } else {
                // If first item, set next's prev to nullptr
                // Set head to next
                current->next->prev = nullptr;
                head = current->next;
            }
            // If not last item
            if (current->next != nullptr) {
                // Point next node *prev to current's prev node
                current->next->prev = current->prev;
            } else {
                // If last item, set prev's next to nullptr
                // Set tail to prev
                current->prev->next = nullptr;
                tail = current->prev;
            }

            // Delete the current node
            delete current;
            m_curSize--;
            return true;
        }
        current = current->next;
    }
    return false;
}
    
bool Map::contains(const KeyType& key) const
{
    Node* current = head;
    while (current != nullptr)
    {
        if (current->key == key)
        {
            return true;
        }
        current = current->next;
    }
    return false;
}

bool Map::get(const KeyType& key, ValueType& value) const
{
    Node* current = head;
    while (current != nullptr)
    {
        if (current->key == key)
        {
            value = current->value;
            return true;
        }
        current = current->next;
    }
    return false;
}

bool Map::get(int i, KeyType& key, ValueType& value) const
{   
    // Check if i is within list
    if (i >= 0 && i < m_curSize)
    {   
        // Iterate through each node
        Node* current = head;
        while (current != nullptr)
        {
            int count = 0;
            // Check if current node's key is greater than other keys
            // If so, increase count
            Node* temp = head;
            while (temp != nullptr)
            {
                if (current->key > temp->key)
                {
                    count++;
                }
                temp = temp->next;
            }
            // If count is equal to i, set key and value and return true
            if (count == i) {
                key = current->key;
                value = current->value;
                return true;
            }
            current = current->next;
        }
    }
    return false;
}

void Map::swap(Map& other)
{   
    // Swap head and tail pointers
    Node* tempHead = head;
    head = other.head;
    other.head = tempHead;

    Node* tempTail = tail;
    tail = other.tail;
    other.tail = tempTail;

    // Swap sizes
    int tempSize = m_curSize;
    m_curSize = other.m_curSize;
    other.m_curSize = tempSize;
}
void Map::dump() const
{
    Node* current = head;
    while (current != nullptr)
    {
        cerr << "key: " << current->key << endl;
        cerr << "value: " << current->value << endl;
        current = current->next;
    }
}

bool merge(const Map& m1, const Map& m2, Map& result)
{   
    bool returnVal = true;
    // To avoid aliasing, create a temp map
    Map temp;
    // // clear result Map
    // while (!result.empty())
    // {
    //     result.erase(result.head->key);
    // }
     // Iterate through m1
    for (int i = 0; i < m1.size(); i++)
    {
        KeyType key;
        ValueType value;
        if (m1.get(i, key, value))
        {
            // Check if key is not in m2
            if (!m2.contains(key))
            {
                temp.insert(key, value);
            }
            else
            {
                // Key is in both maps, check if values are the same
                ValueType value2;
                if (m2.get(key, value2) && value == value2)
                {
                    temp.insert(key, value);
                } else { // Key appears in both maps with different values
                    returnVal = false;
                }
            }
        }
    }
    // Iterate through m2 to find keys not in m1
    for (int i = 0; i < m2.size(); i++)
    {
        KeyType key;
        ValueType value;
        if (m2.get(i, key, value) && !m1.contains(key))
        {
            temp.insert(key, value);
        }
    }
    result.swap(temp);
    return returnVal;
}

void reassign(const Map& m, Map& result)
{   
    // To avoid aliasing, create a temp map
    Map temp;

    // If m has only one pair, copy that pair to the result map
    if (m.size() == 1)
    {
        KeyType key;
        ValueType value;
        m.get(0, key, value);
        temp.insert(key, value);

    } else {
        // Store the first node key and value
        KeyType key1;
        ValueType value1;
        m.get(0, key1, value1);

        KeyType keyA;
        ValueType valueA;
        KeyType keyB;
        ValueType valueB;
        // Iterate from first to 2nd to last nodes
        for (int i = 0; i < m.size() - 1; i++)
        {   
            m.get(i, keyA, valueA);
            m.get(i+1, keyB, valueB);
            // Insert by using current key and next value
            temp.insert(keyA, valueB);
        }
        // Get last key
        m.get(m.size()-1, keyA, valueA);
        // Insert last key with first value, completing a circular shift
        temp.insert(keyA, value1);
    }
    result.swap(temp);
    
}
