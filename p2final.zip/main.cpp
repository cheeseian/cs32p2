#include "Map.h"
#include <iostream>
#include <cassert>
using namespace std;


int main()
{

    Map m;
    m.insert("Ethel", 456);
    m.insert("Fred", 123);
    m.insert("Lucy", 456);
    Map result = m;

    reassign(m, result);
    result.dump();

    // Map m;
    // m.insert("Fred", 123);
    // m.insert("Ethel", 456);
    // m.insert("Lucy", 789);

    // Map m2;
    // m.insert("Ricky", 321);
    // m.insert("Lucy", 789);
    
    // Map result = m;
    // cout << merge(m, m2, result) << endl;
    // result.dump();

}
